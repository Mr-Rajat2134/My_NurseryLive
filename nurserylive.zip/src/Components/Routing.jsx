import React from "react";
import SingleProducts from "../pages/SingleProducts/SingleProducts";
import { Route, Routes } from "react-router-dom";
import Allmodules from "../common/Allmodules";

import AddCart from "../pages/AddCart/AddCart";

const Routing = () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<Allmodules />} />
        <Route path="/addcart" element={<AddCart />} />
        <Route path="/singleproducts/:productId" element={<SingleProducts />} />
      </Routes>
    </>
  );
};

export default Routing;
