import { createTheme } from "@mui/material";



const Theme = createTheme({
    // palette:{
        primary:{
               main:'#FFFFFF',
               Light:'#FF6B6B',
          
        
        // },
      
         
}
})


export default Theme;