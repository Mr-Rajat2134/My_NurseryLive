import cc1 from "../src/Images/circle1.avif";
import cc2 from "../src/Images/circle2.avif";
import cc3 from "../src/Images/circle3.avif";
import cc4 from "../src/Images/circle4.avif";
import cc5 from "../src/Images/circle5.avif";
import cc6 from "../src/Images/circle6.avif";
import cc7 from "../src/Images/circle7.avif";
import cc8 from "../src/Images/circle8.avif";
import cc9 from "../src/Images/circle9.avif";
import cc10 from "../src/Images/circle10.avif";
import s1 from "../src/Images/S1plants.webp";
import s2 from "../src/Images/S2plants.webp";
import s3 from "../src/Images/S3plants.webp";
import s4 from "../src/Images/S4plants.webp";
import s5 from "../src/Images/S5plants.webp";

import Ic1 from "../src/Images/Img1Card.webp";
import Ic2 from "../src/Images/Img2Card.avif";
import Ic3 from "../src/Images/Img3Card.avif";
import Ic4 from "../src/Images/Img4Card.avif";
import Ic5 from "../src/Images/Img5Card.avif";

import bc1 from "../src/Images/Bcircle1.webp";
import bc2 from "../src/Images/Bcircle2.webp";
import bc3 from "../src/Images/Bcircle3.webp";
import bc4 from "../src/Images/Bcircle4.webp";
export const data = [
  {
    id: 1,
    img: cc1,
  },
  {
    id: 2,
    img: cc2,
  },
  {
    id: 3,
    img: cc3,
  },
  {
    id: 4,
    img: cc4,
  },
  {
    id: 5,
    img: cc5,
  },
  {
    id: 6,
    img: cc6,
  },
  {
    id: 7,
    img: cc7,
  },
  {
    id: 8,
    img: cc8,
  },
  {
    id: 9,
    img: cc9,
  },
  {
    id: 10,
    img: cc10,
  },
];

export const silder = [
  {
    id: 1,
    img: s1,
  },
  {
    id: 2,
    img: s2,
  },
  {
    id: 3,
    img: s3,
  },
  {
    id: 4,
    img: s4,
  },
  {
    id: 5,
    img: s5,
  },
];

export const Carddata = [
  {
    id: "1",
    Name: "Tobacco",
    description:
      "He bends! He stretches! He even ties in knots, but always returns to his original shape!Plants are living organisms that grow from soil and use photosynthesis to produce their own food. They are one of five kingdoms of living things, and are autotrophic eukaryotes, meaning they have complex cells and make their own food.",
    price: "219",
    img: Ic1,
    Title: "   5 Best Fragrant Plants 5 Best Fragrant Plants",
    Value: "2",
  },
  {
    id: "2",
    Name: "Spinach",
    description:
      "He bends! He stretches! He even ties in knots, but always returns to his original shape!Plants are living organisms that grow from soil and use photosynthesis to produce their own food. They are one of five kingdoms of living things, and are autotrophic eukaryotes, meaning they have complex cells and make their own food.",
    price: "324",
    img: Ic2,
    Title: "  5 Best Fragrant Plants 5 Best Fragrant Plants",
    Value: "3",
  },
  {
    id: "3",
    Name: "Teak",
    description:
      "He bends! He stretches! He even ties in knots, but always returns to his original shape!Plants are living organisms that grow from soil and use photosynthesis to produce their own food. They are one of five kingdoms of living things, and are autotrophic eukaryotes, meaning they have complex cells and make their own food.",
    img: Ic3,
    price: "473",
    Title: "      5 Best Fragrant Plants 5 Best Fragrant Plants ",
    Value: "5",
  },
  {
    id: "4",
    Name: "Turmeric",
    description:
      "He bends! He stretches! He even ties in knots, but always returns to his original shape!,Plants are living organisms that grow from soil and use photosynthesis to produce their own food. They are one of five kingdoms of living things, and are autotrophic eukaryotes, meaning they have complex cells and make their own food.",
    img: Ic4,
    price: "498",
    Title: "   5 Best Fragrant Plants 5 Best Fragrant Plants",
    Value: "3",
  },
  {
    id: "5",
    Name: "Rose",
    description:
      "He bends! He stretches! He even ties in knots, but always returns to his original shape!Plants are living organisms that grow from soil and use photosynthesis to produce their own food. They are one of five kingdoms of living things, and are autotrophic eukaryotes, meaning they have complex cells and make their own food.",
    img: Ic5,
    price: "123",
    Title: "   5 Best Fragrant Plants 5 Best Fragrant Plants ",
    Value: "4",
  },
  {
    id: "6",
    Name: "Rose",
    description:
      "He bends! He stretches! He even ties in knots, but always returns to his original shape!Plants are living organisms that grow from soil and use photosynthesis to produce their own food. They are one of five kingdoms of living things, and are autotrophic eukaryotes, meaning they have complex cells and make their own food.",
    img: Ic5,
    price: "123",
    Title: "   5 Best Fragrant Plants 5 Best Fragrant Plants ",
    Value: "4",
  },
  {
    id: "7",
    Name: "Rose",
    description:
      "He bends! He stretches! He even ties in knots, but always returns to his original shape!Plants are living organisms that grow from soil and use photosynthesis to produce their own food. They are one of five kingdoms of living things, and are autotrophic eukaryotes, meaning they have complex cells and make their own food.",
    img: Ic5,
    price: "123",
    Title: "   5 Best Fragrant Plants 5 Best Fragrant Plants ",
    Value: "4",
  },
  {
    id: "8",
    Name: "Rose",
    description:
      "He bends! He stretches! He even ties in knots, but always returns to his original shape!Plants are living organisms that grow from soil and use photosynthesis to produce their own food. They are one of five kingdoms of living things, and are autotrophic eukaryotes, meaning they have complex cells and make their own food.",
    img: Ic5,
    price: "123",
    Title: "   5 Best Fragrant Plants 5 Best Fragrant Plants ",
    Value: "4",
  },
  {
    id: "9",
    Name: "Rose",
    description:
      "He bends! He stretches! He even ties in knots, but always returns to his original shape!Plants are living organisms that grow from soil and use photosynthesis to produce their own food. They are one of five kingdoms of living things, and are autotrophic eukaryotes, meaning they have complex cells and make their own food.",
    img: Ic5,
    price: "123",
    Title: "   5 Best Fragrant Plants 5 Best Fragrant Plants ",
    Value: "4",
  },
  {
    id: "10",
    Name: "Rose",
    description:
      "He bends! He stretches! He even ties in knots, but always returns to his original shape!Plants are living organisms that grow from soil and use photosynthesis to produce their own food. They are one of five kingdoms of living things, and are autotrophic eukaryotes, meaning they have complex cells and make their own food.",
    img: Ic5,
    price: "123",
    Title: "   5 Best Fragrant Plants 5 Best Fragrant Plants ",
    Value: "4",
  },
];

export const Bcircledata = [
  {
    id: 1,
    Image: bc1,
    Title: "Bonsai Plants-upto 25% off",
  },
  {
    id: 2,
    Image: bc2,
    Title: "Ceremic Planters-Starting ₹299",
  },
  {
    id: 3,
    Image: bc3,
    Title: "Kokedama-Starting ₹249",
  },
  {
    id: 4,
    Image: bc4,
    Title: "Month Wise Gardening-upto 65% off",
  },
];
