import React from "react";
import { useParams } from "react-router-dom";
import { Carddata } from "../../Dummydata";
import { Box, Button, Container, Grid, Rating, Stack } from "@mui/material";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import BoltIcon from "@mui/icons-material/Bolt";
import Theme from "../../Theme";
import { Female } from "@mui/icons-material";
// import PlantCards from "../../Components/PlantCards/PlantCards";
import GridFor from '../../Components/GridFor/GridFor'
import { useCart } from "../../Components/Functionality/snackbars";

// import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
// import Grid from '@mui/material/Unstable_Grid2';

const SingleProducts = () => {
  const { addToCart } = useCart();
  const { primary } = Theme;
  const { productId } = useParams();
  const thisProduct = Carddata.find((prod) => prod.id === productId);
  return (
    <div>
      {/* design  */}

      <Container fixed>
        <Box
          sx={{
            bgcolor: primary.main,
            minHeight: "80vh",
            marginTop: "1rem",
            padding: "5rem",
            display: {sm :"block" ,md:'flex'},

          }}
        >
          <Box sx={{ padding: "rem" }}>
            {" "}
            <img src={thisProduct.img} alt=""     />
          </Box>

          <Box sx={{ minWidth: "20vw", marginLeft: "3rem",    }}>
            <h1>{thisProduct.Name}</h1>
            <Rating
              size="small"
              name="simple-controlled"
              value={thisProduct.Value}
            />
            <h1  style={{color:primary.Light}}> ₹ {thisProduct.price}</h1>
            <h5> {thisProduct.Title}</h5>
            <p> {thisProduct.description}</p>


            

            <Box
              sx={{
                display: "flex",
                minWidth: "10rem",
                gap: "2rem",
                marginTop: "5rem",
                justifyContent:'flex-end'
              }}
            >
              <Button
              onClick={() => {
                addToCart();
                showSnackbar(`${product.Title} added to cart`);
              }}
                startIcon={<ShoppingCartIcon />}
                sx={{
                  mt: "0.1rem",
                  color: primary.Main,
                  backgroundColor: primary.Light,
                  ":hover": { bgcolor: "#ff6b6bc6" },
                }}
                variant="contained"
                // size="small"
              >
                Add Card
              </Button>
              <Button
                startIcon={<BoltIcon />}
                sx={{
                  mt: "0.1rem",
                  color: primary.Main,
                  backgroundColor: primary.Light,
                  ":hover": { bgcolor: "#ff6b6bc6" },
                }}
                variant="contained"
                // size="small"
              >
                BY NOW
              </Button>
            </Box>
          </Box>
        </Box>

        {/* <Box  width={'100%'}  > */}

        <GridFor/>

        {/* </Box> */}
      </Container>
    </div>
  );
};

export default SingleProducts;
