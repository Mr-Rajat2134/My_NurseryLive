import React from 'react'

const AddCart = () => {
  return (
    <div>
      ghghjgjhgjhgjh
      
    </div>
  )
}

export default AddCart
